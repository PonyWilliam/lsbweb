var config = {
	url:'https://lsbserver.dadiqq.cn/',
	maptype:'gcj02',
	
}
export {config}