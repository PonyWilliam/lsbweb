var config = {
	url:'https://lsbserver.dadiqq.cn/',
	maptype:'gcj-02',
	
}
export {config}